
import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, User } from 'lucide-react';

const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Thank you for your message! Our team will get back to you shortly.");
    setFormData({ name: '', phone: '', email: '', subject: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.id]: e.target.value }));
  };

  return (
    <div className="bg-white min-h-screen">
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">Contact Us</h1>
        <p className="mt-4 text-gray-300">We are ready to discuss your next big project</p>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="flex flex-col lg:flex-row gap-16">
          {/* Contact Form */}
          <div className="lg:w-3/5">
            <h2 className="text-3xl font-bold text-corporateBlue mb-8">Send Us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="name" className="text-sm font-bold text-gray-700">Full Name</label>
                  <input 
                    required 
                    type="text" 
                    id="name" 
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-industrialGrey rounded-lg border-transparent focus:border-professionalGreen focus:bg-white focus:ring-0 transition-all outline-none" 
                    placeholder="Enter your name" 
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="phone" className="text-sm font-bold text-gray-700">Phone Number</label>
                  <input 
                    required 
                    type="tel" 
                    id="phone" 
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-industrialGrey rounded-lg border-transparent focus:border-professionalGreen focus:bg-white focus:ring-0 transition-all outline-none" 
                    placeholder="Enter your phone" 
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="email" className="text-sm font-bold text-gray-700">Email Address</label>
                  <input 
                    required 
                    type="email" 
                    id="email" 
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-industrialGrey rounded-lg border-transparent focus:border-professionalGreen focus:bg-white focus:ring-0 transition-all outline-none" 
                    placeholder="Enter your email" 
                  />
                </div>
                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm font-bold text-gray-700">Subject</label>
                  <input 
                    required 
                    type="text" 
                    id="subject" 
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-industrialGrey rounded-lg border-transparent focus:border-professionalGreen focus:bg-white focus:ring-0 transition-all outline-none" 
                    placeholder="Project Inquiry" 
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="message" className="text-sm font-bold text-gray-700">Message</label>
                <textarea 
                  required 
                  id="message" 
                  rows={6}
                  value={formData.message}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-industrialGrey rounded-lg border-transparent focus:border-professionalGreen focus:bg-white focus:ring-0 transition-all outline-none resize-none" 
                  placeholder="How can we help you?"
                ></textarea>
              </div>
              <button 
                type="submit" 
                className="bg-professionalGreen text-white px-10 py-4 rounded-full font-bold hover:bg-green-700 transition-all transform hover:scale-105 flex items-center space-x-3"
              >
                <span>Submit Inquiry</span>
                <Send size={18} />
              </button>
            </form>
          </div>

          {/* Contact Details */}
          <div className="lg:w-2/5 space-y-8">
            <h2 className="text-3xl font-bold text-corporateBlue mb-8">Get In Touch</h2>
            <div className="bg-corporateBlue text-white p-10 rounded-3xl shadow-xl space-y-8">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-professionalGreen mt-1 shrink-0">
                  <User size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Contact Person</h4>
                  <p className="text-gray-300">Tanmoy Datta</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-professionalGreen mt-1 shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Phone</h4>
                  <p className="text-gray-300">6290713394 / 9748765805</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-professionalGreen mt-1 shrink-0">
                  <Mail size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Email</h4>
                  <p className="text-gray-300">radhakrishnaenterprise@gmail.com</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center text-professionalGreen mt-1 shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-lg">Address</h4>
                  <p className="text-gray-300">194/1, Sitalatala Road, Chatra,<br />Shrirampur, Hooghly - 712204, West Bengal</p>
                </div>
              </div>
            </div>

            {/* Google Maps Placeholder */}
            <div className="rounded-3xl overflow-hidden shadow-lg h-64 relative bg-industrialGrey border-2 border-dashed border-gray-300">
              <div className="absolute inset-0 flex items-center justify-center text-gray-500 font-bold uppercase tracking-tight p-6 text-center">
                Office Location - 194/1, Sitalatala Road, Chatra, Shrirampur, Hooghly, W.B<br />Pin - 712204
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
