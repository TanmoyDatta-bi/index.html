
import React from 'react';
import * as LucideIcons from 'lucide-react';
import { SERVICES } from '../constants';

const Services: React.FC = () => {
  return (
    <div className="bg-industrialGrey min-h-screen pb-20">
      {/* Page Header */}
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">Our Services</h1>
        <p className="mt-4 text-gray-300">Specialized Electrical & Instrumentation Solutions</p>
      </div>

      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, idx) => {
            const IconComponent = (LucideIcons as any)[service.icon] || LucideIcons.Zap;
            return (
              <div 
                key={idx} 
                className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-xl transition-all border-b-4 border-transparent hover:border-professionalGreen group transform hover:-translate-y-2"
              >
                <div className="w-16 h-16 bg-industrialGrey rounded-xl flex items-center justify-center mb-6 text-corporateBlue group-hover:bg-professionalGreen group-hover:text-white transition-colors">
                  <IconComponent size={32} />
                </div>
                <h3 className="text-xl font-bold text-professionalGreen mb-3 group-hover:text-corporateBlue transition-colors">{service.title}</h3>
                <p className="text-gray-600 leading-relaxed">{service.description}</p>
                <div className="mt-6 flex items-center text-corporateBlue font-bold text-sm group-hover:text-professionalGreen cursor-pointer">
                  Learn More <LucideIcons.ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Specialty Section */}
      <div className="container mx-auto px-4 mt-12">
        <div className="bg-white rounded-3xl overflow-hidden shadow-lg flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-12 flex flex-col justify-center">
            <h2 className="text-professionalGreen font-bold mb-2 tracking-widest uppercase text-sm">Authorized Centre</h2>
            <h3 className="text-3xl font-bold text-corporateBlue mb-6">Authorized TDK (EPCOS) Service Centre</h3>
            <p className="text-gray-600 mb-6 leading-relaxed">
              As an official TDK partner since our inception, we specialize in high-precision power factor correction and power quality management. Our engineers are trained by TDK to ensure that your APFC panels operate at peak performance, ensuring a power factor of 0.99+ and significantly reducing utility penalties.
            </p>
            <ul className="space-y-3">
              {["Genuine Spares", "Expert Calibration", "Harmonic Analysis", "Performance Audits"].map((item, idx) => (
                <li key={idx} className="flex items-center space-x-2 text-gray-700 font-medium">
                  <LucideIcons.CheckCircle size={18} className="text-professionalGreen" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="lg:w-1/2">
            <img src="https://images.unsplash.com/photo-1544724569-5f546fd6f2b5?auto=format&fit=crop&q=80&w=800" alt="Technical Electrical Work" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;
