
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail, MessageCircle } from 'lucide-react';

const NavLink: React.FC<{ to: string; label: string; active: boolean; onClick?: () => void }> = ({ to, label, active, onClick }) => (
  <Link
    to={to}
    onClick={onClick}
    className={`px-3 py-2 text-sm font-bold transition-all border-b-2 ${
      active ? 'border-professionalGreen text-professionalGreen' : 'border-transparent hover:border-professionalGreen hover:text-professionalGreen'
    }`}
  >
    {label}
  </Link>
);

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const menuItems = [
    { path: '/', label: 'Home' },
    { path: '/about', label: 'About Us' },
    { path: '/services', label: 'Services' },
    { path: '/projects', label: 'Projects' },
    { path: '/clients', label: 'Clients' },
    { path: '/tools', label: 'Tools' },
    { path: '/statutory', label: 'Statutory' },
    { path: '/contact', label: 'Contact Us' },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow-md">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-12 h-12 bg-corporateBlue rounded-full flex items-center justify-center text-white font-bold text-xl">RK</div>
              <div className="flex flex-col">
                <span className="text-professionalGreen font-bold text-lg leading-tight">M/s Radha Krishna</span>
                <span className="text-corporateBlue text-xs font-bold uppercase tracking-wider">Enterprise</span>
              </div>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center space-x-4">
              {menuItems.map((item) => (
                <NavLink key={item.path} to={item.path} label={item.label} active={location.pathname === item.path} />
              ))}
              <Link
                to="/contact"
                className="ml-4 bg-professionalGreen text-white px-6 py-2 rounded-full font-bold hover:bg-green-700 transition-all transform hover:scale-105"
              >
                Request a Quote
              </Link>
            </nav>

            {/* Mobile Menu Toggle */}
            <button className="lg:hidden p-2" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>

        {/* Mobile Nav */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-100 py-4 px-4 shadow-xl">
            <div className="flex flex-col space-y-4">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`text-base font-bold ${
                    location.pathname === item.path ? 'text-professionalGreen' : 'text-gray-800'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
              <Link
                to="/contact"
                onClick={() => setIsMenuOpen(false)}
                className="bg-professionalGreen text-white px-6 py-3 rounded-md font-bold text-center"
              >
                Request a Quote
              </Link>
            </div>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-corporateBlue text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div>
              <h3 className="text-xl font-bold mb-4">M/s Radha Krishna Enterprise</h3>
              <p className="text-gray-300 leading-relaxed mb-4">
                Authorized TDK (EPCOS) Service Centre since 2009. Leading turnkey contractor for Electrical & Instrumentation solutions.
              </p>
              <div className="flex space-x-4">
                <div className="w-10 h-10 bg-white/10 rounded flex items-center justify-center hover:bg-professionalGreen transition-all cursor-pointer">
                  <span className="font-bold">IN</span>
                </div>
                <div className="w-10 h-10 bg-white/10 rounded flex items-center justify-center hover:bg-professionalGreen transition-all cursor-pointer">
                  <span className="font-bold">FB</span>
                </div>
              </div>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <ul className="space-y-2">
                {menuItems.slice(0, 5).map(item => (
                  <li key={item.path}>
                    <Link to={item.path} className="text-gray-300 hover:text-white transition-colors">
                      {item.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4">Contact Info</h3>
              <ul className="space-y-4">
                <li className="flex items-start space-x-3">
                  <Phone size={20} className="text-professionalGreen mt-1" />
                  <div>
                    <p className="text-gray-300">6290713394 / 9748765805</p>
                  </div>
                </li>
                <li className="flex items-start space-x-3">
                  <Mail size={20} className="text-professionalGreen mt-1" />
                  <p className="text-gray-300">radhakrishnaenterprise@gmail.com</p>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 mt-12 pt-8 text-center text-sm text-gray-400">
            © {new Date().getFullYear()} M/s Radha Krishna Enterprise – All Rights Reserved.
          </div>
        </div>
      </footer>

      {/* Floating Mobile Actions */}
      <div className="fixed bottom-6 left-6 z-40">
        <a
          href="https://wa.me/916290713394"
          target="_blank"
          rel="noopener noreferrer"
          className="bg-green-500 text-white p-3 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center"
        >
          <MessageCircle size={24} />
        </a>
      </div>
      <div className="fixed bottom-6 right-6 z-40">
        <a
          href="mailto:radhakrishnaenterprise@gmail.com"
          className="bg-corporateBlue text-white p-3 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center"
        >
          <Mail size={24} />
        </a>
      </div>
    </div>
  );
};

export default Layout;
