
import React from 'react';
import { CLIENT_LOGOS, CLIENT_PROJECTS } from '../constants';

const Clients: React.FC = () => {
  return (
    <div className="bg-white pb-20">
      {/* Page Header */}
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">Our Clients</h1>
        <p className="mt-4 text-gray-300">Trusted by industry leaders across India</p>
      </div>

      <div className="container mx-auto px-4 py-16">
        {/* Vendor Grid */}
        <div className="mb-20">
          <h2 className="text-2xl font-bold text-corporateBlue mb-8 text-center uppercase tracking-widest">Registered Vendor Portfolio</h2>
          <div className="flex flex-wrap justify-center gap-6">
            {CLIENT_LOGOS.map((client, idx) => (
              <div key={idx} className="bg-industrialGrey px-8 py-6 rounded-xl flex items-center justify-center min-w-[180px] hover:bg-professionalGreen hover:text-white transition-all cursor-default font-bold text-corporateBlue text-center shadow-sm">
                {client}
              </div>
            ))}
          </div>
        </div>

        {/* Project Table */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-corporateBlue mb-8 border-l-4 border-professionalGreen pl-4">Significant Project Milestone</h2>
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
            <table className="w-full text-left">
              <thead className="bg-corporateBlue text-white">
                <tr>
                  <th className="px-6 py-4 font-bold">Client Name</th>
                  <th className="px-6 py-4 font-bold text-right">Project Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {CLIENT_PROJECTS.map((project, idx) => (
                  <tr key={idx} className="hover:bg-industrialGrey transition-colors">
                    <td className="px-6 py-4 text-gray-800 font-medium">{project.name}</td>
                    <td className="px-6 py-4 text-right font-bold text-professionalGreen">{project.value}</td>
                  </tr>
                ))}
                <tr className="bg-industrialGrey font-bold">
                  <td className="px-6 py-4 text-corporateBlue">Plus 40+ Other Projects</td>
                  <td className="px-6 py-4 text-right text-gray-400">Ongoing</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Quote Section */}
        <div className="mt-20 text-center max-w-2xl mx-auto px-4">
          <blockquote className="italic text-gray-500 text-xl border-l-4 border-professionalGreen pl-6 py-2">
            "M/s Radha Krishna Enterprise has consistently delivered high-quality electrical installations within stipulated timelines. Their technical knowledge is unmatched in the region."
          </blockquote>
          <p className="mt-4 font-bold text-corporateBlue">— Leading Project Consultant</p>
        </div>
      </div>
    </div>
  );
};

export default Clients;
