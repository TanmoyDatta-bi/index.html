
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Award, Settings, Building2, ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  {
    image: 'https://images.unsplash.com/photo-1621905251189-08b45d6a269e?auto=format&fit=crop&q=80&w=1920',
    title: 'M/s Radha Krishna Enterprise',
    subtitle: 'Industrial Electrical Installations & Turnkey Solutions'
  },
  {
    image: 'https://images.unsplash.com/photo-1544724569-5f546fd6f2b5?auto=format&fit=crop&q=80&w=1920',
    title: 'PCC & MCC Panel Board Specialists',
    subtitle: 'Trusted Partner for Advanced Power Distribution Systems'
  }
];

const Home: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div>
      {/* Hero Carousel */}
      <section className="relative h-[80vh] overflow-hidden">
        {slides.map((slide, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
              index === currentSlide ? 'opacity-100 z-10' : 'opacity-0 z-0'
            }`}
          >
            <img src={slide.image} alt={slide.title} className="w-full h-full object-cover brightness-[0.4]" />
            <div className="absolute inset-0 flex items-center justify-center text-center text-white px-4">
              <div className="max-w-4xl transform transition-all duration-700 translate-y-0">
                <h1 className="text-4xl md:text-6xl font-bold mb-4 drop-shadow-lg">{slide.title}</h1>
                <p className="text-xl md:text-2xl mb-8 drop-shadow-md text-gray-200">{slide.subtitle}</p>
                <div className="flex flex-col md:flex-row items-center justify-center space-y-4 md:space-y-0 md:space-x-4">
                  <Link to="/services" className="bg-professionalGreen hover:bg-green-700 text-white px-8 py-3 rounded-full font-bold transition-all w-full md:w-auto">
                    View Our Services
                  </Link>
                  <Link to="/contact" className="bg-white hover:bg-gray-100 text-corporateBlue px-8 py-3 rounded-full font-bold transition-all w-full md:w-auto">
                    Contact Us
                  </Link>
                </div>
              </div>
            </div>
          </div>
        ))}
        
        {/* Carousel Navigation */}
        <button 
          onClick={() => setCurrentSlide(prev => (prev - 1 + slides.length) % slides.length)}
          className="absolute left-4 top-1/2 -translate-y-1/2 z-20 text-white/50 hover:text-white transition-colors"
        >
          <ChevronLeft size={48} />
        </button>
        <button 
          onClick={() => setCurrentSlide(prev => (prev + 1) % slides.length)}
          className="absolute right-4 top-1/2 -translate-y-1/2 z-20 text-white/50 hover:text-white transition-colors"
        >
          <ChevronRight size={48} />
        </button>
      </section>

      {/* Intro Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <h2 className="text-professionalGreen text-3xl md:text-4xl font-bold mb-6">16+ Years of Excellence in Electrical Solutions</h2>
            <p className="text-gray-600 text-lg leading-relaxed">
              M/s Radha Krishna Enterprise, established in 2009, is a reputed Electrical & Instrumentation turnkey contractor based in West Bengal. We specialize in industrial automation, power distribution, and power factor correction with a track record of serving major blue-chip clients across India.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center group">
              <div className="w-16 h-16 bg-industrialGrey rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-professionalGreen group-hover:text-white transition-all text-corporateBlue">
                <Calendar size={32} />
              </div>
              <h4 className="font-bold text-gray-900">Established 2009</h4>
              <p className="text-sm text-gray-500 mt-1">Founding Year</p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 bg-industrialGrey rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-professionalGreen group-hover:text-white transition-all text-corporateBlue">
                <Award size={32} />
              </div>
              <h4 className="font-bold text-gray-900">Authorized TDK</h4>
              <p className="text-sm text-gray-500 mt-1">Service Centre</p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 bg-industrialGrey rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-professionalGreen group-hover:text-white transition-all text-corporateBlue">
                <Settings size={32} />
              </div>
              <h4 className="font-bold text-gray-900">Turnkey Expertise</h4>
              <p className="text-sm text-gray-500 mt-1">End-to-end Support</p>
            </div>
            <div className="text-center group">
              <div className="w-16 h-16 bg-industrialGrey rounded-xl flex items-center justify-center mx-auto mb-4 group-hover:bg-professionalGreen group-hover:text-white transition-all text-corporateBlue">
                <Building2 size={32} />
              </div>
              <h4 className="font-bold text-gray-900">Industrial & Commercial</h4>
              <p className="text-sm text-gray-500 mt-1">Multi-Sector Solutions</p>
            </div>
          </div>
        </div>
      </section>

      {/* Quick CTA */}
      <section className="bg-corporateBlue py-16 text-white text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-4">Ready to optimize your electrical infrastructure?</h2>
          <p className="text-gray-300 mb-8 max-w-2xl mx-auto">Get in touch with our experts for a customized quote tailored to your specific industrial requirements.</p>
          <Link to="/contact" className="bg-professionalGreen hover:bg-green-700 px-10 py-4 rounded-full font-bold transition-all inline-block">
            Request a Free Consultation
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;
