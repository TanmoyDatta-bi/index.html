
import React from 'react';
import { ShieldCheck, FileCheck, Landmark, ClipboardList } from 'lucide-react';
import { STATUTORY } from '../constants';

const Statutory: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">Statutory & Registration</h1>
        <p className="mt-4 text-gray-300">Transparency and compliance are at the heart of our operations</p>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto">
          <div className="grid grid-cols-1 gap-6">
            {STATUTORY.map((item, idx) => (
              <div 
                key={idx} 
                className="bg-industrialGrey flex items-center justify-between p-6 rounded-2xl border-2 border-transparent hover:border-professionalGreen transition-all group"
              >
                <div className="flex items-center space-x-6">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-professionalGreen shadow-sm group-hover:scale-110 transition-transform">
                    <ShieldCheck size={24} />
                  </div>
                  <span className="text-xl font-bold text-corporateBlue">{item}</span>
                </div>
                <div className="hidden sm:block text-professionalGreen font-bold uppercase tracking-widest text-xs">
                  Active / Valid
                </div>
              </div>
            ))}
          </div>

          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-8 bg-white border border-gray-100 shadow-lg rounded-2xl">
              < Landmark size={40} className="mx-auto text-corporateBlue mb-4" />
              <h4 className="font-bold text-corporateBlue mb-2">Banking Partner</h4>
              <p className="text-gray-500 text-sm">HDFC Bank, Serampore Branch</p>
            </div>
            <div className="text-center p-8 bg-white border border-gray-100 shadow-lg rounded-2xl">
              < FileCheck size={40} className="mx-auto text-corporateBlue mb-4" />
              <h4 className="font-bold text-corporateBlue mb-2">Audit Status</h4>
              <p className="text-gray-500 text-sm">Audited annually by Chartered Accountants</p>
            </div>
            <div className="text-center p-8 bg-white border border-gray-100 shadow-lg rounded-2xl">
              < ClipboardList size={40} className="mx-auto text-corporateBlue mb-4" />
              <h4 className="font-bold text-corporateBlue mb-2">Ethics Code</h4>
              <p className="text-gray-500 text-sm">Compliant with all labor and environmental laws</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Statutory;
