
import React from 'react';
import { PROJECTS } from '../constants';

const Projects: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Page Header */}
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">Turnkey Projects</h1>
        <p className="mt-4 text-gray-300">Showcasing our precision engineering and on-time delivery</p>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PROJECTS.map((project, idx) => (
            <div 
              key={idx} 
              className="group relative overflow-hidden rounded-2xl shadow-lg aspect-square cursor-pointer"
            >
              <img 
                src={project.imageUrl} 
                alt={project.title} 
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
              />
              <div className="absolute inset-0 bg-gradient-to-t from-corporateBlue/90 via-corporateBlue/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-8">
                <p className="text-professionalGreen font-bold text-sm mb-2 uppercase tracking-widest">{project.category}</p>
                <h3 className="text-white text-2xl font-bold">{project.title}</h3>
                <div className="h-1 w-0 group-hover:w-16 bg-professionalGreen mt-4 transition-all duration-500"></div>
              </div>
            </div>
          ))}
        </div>

        {/* Milestone Text */}
        <div className="mt-20 bg-industrialGrey rounded-3xl p-12 text-center">
          <h3 className="text-3xl font-bold text-corporateBlue mb-6">Ready to Power Your Next Industrial Venture?</h3>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Whether it's a greenfield project or a system upgrade, we bring 15+ years of turnkey expertise to ensure your facility is wired for success.
          </p>
          <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
             <div className="bg-white px-6 py-4 rounded-xl shadow-sm border border-gray-100">
               <span className="block text-professionalGreen font-bold text-2xl">50+</span>
               <span className="text-gray-500 text-sm">Major Projects</span>
             </div>
             <div className="bg-white px-6 py-4 rounded-xl shadow-sm border border-gray-100">
               <span className="block text-professionalGreen font-bold text-2xl">100%</span>
               <span className="text-gray-500 text-sm">Safety Compliance</span>
             </div>
             <div className="bg-white px-6 py-4 rounded-xl shadow-sm border border-gray-100">
               <span className="block text-professionalGreen font-bold text-2xl">0.99</span>
               <span className="text-gray-500 text-sm">Power Factor Target</span>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Projects;
