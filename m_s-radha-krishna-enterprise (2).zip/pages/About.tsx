
import React from 'react';
import { Target, Lightbulb, Users } from 'lucide-react';

const About: React.FC = () => {
  return (
    <div className="bg-white">
      {/* Page Header */}
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">About Us</h1>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div>
            <h2 className="text-3xl font-bold text-corporateBlue mb-6 border-l-4 border-professionalGreen pl-4">Company Overview</h2>
            <p className="text-gray-600 leading-relaxed mb-4">
              M/s Radha Krishna Enterprise is a distinguished name in the electrical and instrumentation contracting domain. Since our inception in 2009, we have been committed to delivering high-quality turnkey solutions that empower industrial and commercial enterprises.
            </p>
            <p className="text-gray-600 leading-relaxed mb-4">
              As an authorized service centre for TDK (EPCOS), we possess specialized expertise in Power Factor improvement and harmonics mitigation. Our team of seasoned professionals is dedicated to safety, innovation, and absolute client satisfaction.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Based in Serampore, West Bengal, we have successfully executed projects across diverse terrains, handling complex electrical infrastructures with precision and technical prowess.
            </p>
          </div>
          <div className="rounded-2xl overflow-hidden shadow-2xl">
            <img src="https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800" alt="Industrial Electrical and Electronics Systems" className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Strengths Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-24">
          <div className="bg-industrialGrey p-8 rounded-2xl border-b-4 border-transparent hover:border-professionalGreen transition-all hover:-translate-y-2 group">
            <div className="w-14 h-14 bg-white rounded-lg flex items-center justify-center text-professionalGreen mb-6 shadow-md">
              <Target size={28} />
            </div>
            <h3 className="text-xl font-bold mb-4 text-corporateBlue">Our Vision</h3>
            <p className="text-gray-600">To deliver reliable, energy-efficient, and future-ready electrical solutions that drive industrial growth and sustainability across India.</p>
          </div>
          <div className="bg-industrialGrey p-8 rounded-2xl border-b-4 border-transparent hover:border-professionalGreen transition-all hover:-translate-y-2">
            <div className="w-14 h-14 bg-white rounded-lg flex items-center justify-center text-professionalGreen mb-6 shadow-md">
              <Lightbulb size={28} />
            </div>
            <h3 className="text-xl font-bold mb-4 text-corporateBlue">Our Mission</h3>
            <p className="text-gray-600">Committed to providing quality workmanship, adhering to stringent safety compliance, and meeting project timelines without compromise.</p>
          </div>
          <div className="bg-industrialGrey p-8 rounded-2xl border-b-4 border-transparent hover:border-professionalGreen transition-all hover:-translate-y-2">
            <div className="w-14 h-14 bg-white rounded-lg flex items-center justify-center text-professionalGreen mb-6 shadow-md">
              <Users size={28} />
            </div>
            <h3 className="text-xl font-bold mb-4 text-corporateBlue">Manpower</h3>
            <p className="text-gray-600">Supported by a skilled team of 12+ qualified professionals, engineers, and technicians who bring years of on-ground field experience.</p>
          </div>
        </div>

        {/* Industry Experience */}
        <div className="bg-corporateBlue rounded-3xl p-12 text-white">
          <h3 className="text-2xl font-bold mb-8 text-center">Industry Experience</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {["Process Plants", "Foundries", "Dairy / UHT Plants", "Aluminum Plants", "Commercial Complexes", "Automotive Plants"].map((item, idx) => (
              <div key={idx} className="flex items-center space-x-3 bg-white/10 p-4 rounded-xl">
                <div className="w-2 h-2 bg-professionalGreen rounded-full"></div>
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
