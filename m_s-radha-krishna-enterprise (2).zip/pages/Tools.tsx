
import React from 'react';
import * as LucideIcons from 'lucide-react';
import { TOOLS } from '../constants';

const Tools: React.FC = () => {
  return (
    <div className="bg-industrialGrey min-h-screen">
      <div className="bg-corporateBlue py-20 text-white text-center">
        <h1 className="text-4xl font-bold">Tools & Infrastructure</h1>
        <p className="mt-4 text-gray-300">Equipped with state-of-the-art technical specifications</p>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {TOOLS.map((cat, idx) => {
            const IconComponent = (LucideIcons as any)[cat.icon] || LucideIcons.Wrench;
            return (
              <div key={idx} className="bg-white p-10 rounded-3xl shadow-md border border-gray-100 hover:shadow-2xl transition-all">
                <div className="flex items-center space-x-4 mb-8">
                  <div className="w-16 h-16 bg-corporateBlue rounded-2xl flex items-center justify-center text-white shadow-lg">
                    <IconComponent size={32} />
                  </div>
                  <h3 className="text-2xl font-bold text-corporateBlue">{cat.title}</h3>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {cat.items.map((item, iIdx) => (
                    <div key={iIdx} className="flex items-start space-x-3 bg-industrialGrey/50 p-4 rounded-xl border-l-4 border-professionalGreen">
                      <div className="mt-1">
                        <LucideIcons.Check size={16} className="text-professionalGreen font-bold" />
                      </div>
                      <span className="text-gray-700 font-medium">{item.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Safety Note */}
        <div className="mt-16 bg-white rounded-3xl p-12 text-center border-2 border-dashed border-gray-200">
          <LucideIcons.ShieldAlert size={48} className="mx-auto text-professionalGreen mb-6" />
          <h3 className="text-2xl font-bold text-corporateBlue mb-4">Quality & Maintenance Assurance</h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            All our tools and testing equipment undergo periodic calibration and maintenance to ensure the highest standards of accuracy and safety at project sites. We maintain full records of equipment health as per ISO standards.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Tools;
